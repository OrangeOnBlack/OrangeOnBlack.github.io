﻿Imports System.Net.Mail

Public Class Form1

    'Variablen definieren
    Dim email As New MailMessage
    Dim userdata As New System.Net.NetworkCredential
    Dim smtpsrv As New SmtpClient()

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        ProgressBar1.Value = 50
        Label4.Text = "SMTP-Verbindung herstellen"

        smtpsrv.UseDefaultCredentials = False
        smtpsrv.Credentials = userdata


        'SSL aktivieren
            If CheckBox1.Checked = True Then
                smtpsrv.EnableSsl = True
            Else : smtpsrv.EnableSsl = False
            End If

        'eMail beinhaltet HTML
        If CheckBox2.Checked = True Then
            email.IsBodyHtml = True
        Else : email.IsBodyHtml = False
        End If

        'eMail Inhalt füllen
        email.To.Add(TextBox1.Text)
        email.Subject = TextBox2.Text
        email.Body = TextBox3.Text

        'Anhaenge beifügen
        For i As Integer = 1 To ListBox1.Items.Count
            email.Attachments.Add(New Attachment(ListBox1.Items(i - 1)))
        Next

        ProgressBar1.Value = 25
        Label4.Text = "eMail Anhänge beifügen"

        Try
            'eMail senden
            smtpsrv.Send(email)
            MsgBox("eMail erfolgreich gesendet!", MsgBoxStyle.Information)
            Label4.Text = "eMail-Versand abgeschlossen"
        Catch
            'Falls Fehler auftreten
            MsgBox("Fehler!", MsgBoxStyle.Critical)
            Label4.Text = ""
            ProgressBar1.Value = 0
        End Try


        'Bei mehrmaligem Senden werden mehr als eine eMail gesendet
        'Erstes Mal Senden = 1 eMail
        'Zweites Mal Senden = 2 eMails (die Erste nicht mitgezaehlt!)
        '...
        'Das passiert, da jeweils immer der selbe Empfaenger nocheinmal hinzugefügt wird
        'Nachfolgend wird die Empfängerliste nach dem Senden geleert.
        email.To.Clear()
        ProgressBar1.Value = 0
        Label4.Text = ""

        'eMail Anhaenge entleeren
        email.Attachments.Clear()

    End Sub

    Private Sub ComboBox1_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedValueChanged

        'SMTP-Server & Port festlegen
        'Benutzername & Passwort & Absender 
        ' fuer die jew. Mail-Addresse festlegen
        If ComboBox1.SelectedItem = "EMAIL_1_HIER_EINTRAGEN" Then
            smtpsrv.Host = "smtp.gmx.net" 'SMTP-Server fuer GMX-Nutzer
            smtpsrv.Port = 25

            'Daten fuer Nutzer 1
            userdata.UserName = "EMAIL_1_HIER_EINTRAGEN"
            userdata.Password = "PASSWORT_HIER_EINTRAGEN"
            email.From = New MailAddress("EMAIL_1_HIER_EINTRAGEN")


        ElseIf ComboBox1.SelectedItem = "EMAIL_2_HIER_EINTRAGEN" Then
            smtpsrv.Host = "smtp.gmail.com" 'SMTP-Server fuer GoogleMail-Nutzer
            smtpsrv.Port = 25

            'Daten fuer Nutzer 2
            userdata.UserName = "EMAIL_2_HIER_EINTRAGEN"
            userdata.Password = "PASSWORT_HIER_EINTRAGEN"
            email.From = New MailAddress("EMAIL_2_HIER_EINTRAGEN")

        End If

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ComboBox1.Focus()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        'Anhang hinzufügen
        OpenFileDialog1.ShowDialog()
        ListBox1.Items.Add(OpenFileDialog1.FileName)

    End Sub

    Private Sub ListBox1_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedValueChanged

        'Anhang entfernen
        ListBox1.Items.Remove(ListBox1.SelectedItem)

    End Sub

End Class
