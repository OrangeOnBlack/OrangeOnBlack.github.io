﻿Public Class Form1
    Dim timetoken As Long = DateDiff("d", Now.Date, "27.02.2011")
    'Server/Login Daten
    Dim server As String = "SERVER_ADRESSE_HIER_EINTRAGEN"
    Dim username As String = "SERVER_USER_HIER_EINTRAGEN"
    Dim password As String = "USER_PASSWORT_HIER_EINTRAGEN"

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        'Ausgewaehlte Datei hochladen
        Try
            If timetoken >= 0 Then
                My.Computer.Network.UploadFile(OpenFileDialog1.FileName, "ftp://" & server & "/" & OpenFileDialog1.SafeFileName, username, password, True, 10, FileIO.UICancelOption.ThrowException)
            Else : MsgBox("Upload failed!" & vbNewLine & "The time token ran out of time. No, chance. Sorry ...", MsgBoxStyle.Critical, "hmm, something went wrong ...")
            End If
        Catch
            MsgBox("Upload failed!" & vbNewLine & "Please check username, password & server address ..." & vbNewLine & "Or maybe the file already exists.", MsgBoxStyle.Critical, "hmm, something went wrong ...")
        End Try

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        'Die hochzuladende Datei ausweaehlen
        OpenFileDialog1.ShowDialog()
        TextBox1.Text = OpenFileDialog1.FileName

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox1.Focus()
        'Ueberpruefung ob das Programm bereits abgelaufen ist.
        If timetoken < 0 Then
            Me.Text += " [expired!]"
        Else
            Me.Text += " [" & timetoken & " days remain]"
        End If

    End Sub

End Class