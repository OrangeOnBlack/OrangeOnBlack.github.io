﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Allgemeine Informationen über eine Assembly werden über die folgenden 
' Attribute gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
' die mit einer Assembly verknüpft sind.

' Die Werte der Assemblyattribute überprüfen

<Assembly: AssemblyTitle("realer Festplatten-Speicher")> 
<Assembly: AssemblyDescription("Ein kleines Tool, mit dessen Hilfe man den realen Festplatten-Speicher errechnen kann.")> 
<Assembly: AssemblyCompany("OrangeOnBlack")> 
<Assembly: AssemblyProduct("realer Festplatten-Speicher")> 
<Assembly: AssemblyCopyright("Copyright © OrangeOnBlack 2011")> 
<Assembly: AssemblyTrademark("OrangeOnBlack")> 

<Assembly: ComVisible(False)>

'Die folgende GUID bestimmt die ID der Typbibliothek, wenn dieses Projekt für COM verfügbar gemacht wird
<Assembly: Guid("2cd176bf-e6a8-4f0e-8304-cf0517ba998b")> 

' Versionsinformationen für eine Assembly bestehen aus den folgenden vier Werten:
'
'      Hauptversion
'      Nebenversion 
'      Buildnummer
'      Revision
'
' Sie können alle Werte angeben oder die standardmäßigen Build- und Revisionsnummern 
' übernehmen, indem Sie "*" eingeben:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("0.0.0.1")> 
<Assembly: AssemblyFileVersion("0.0.0.1")> 
