﻿Public Class Form1

    Private Sub TextBox1_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.GotFocus
        If TextBox1.Focused = True Then TextBox1.BackColor = SystemColors.ButtonFace
    End Sub

    Private Sub TextBox1_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.LostFocus
        If TextBox1.Focused = False Then TextBox1.BackColor = Color.White
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        Try
            If TextBox1.Text <> Nothing Then
                Label1.Text = Format(TextBox1.Text * 1000 * 1000 * 1000 / 1024 / 1024 / 1024, "0.0") & " GB"
            End If
        Catch
        End Try

        If TextBox1.Text = "" Or Nothing Then
            Label1.Text = 0 & " GB"
        End If

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox1.Focus()
    End Sub
End Class
