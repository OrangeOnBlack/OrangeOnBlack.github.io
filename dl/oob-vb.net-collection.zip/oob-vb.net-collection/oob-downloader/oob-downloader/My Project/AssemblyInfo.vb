﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Allgemeine Informationen über eine Assembly werden über die folgenden 
' Attribute gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
' die mit einer Assembly verknüpft sind.

' Die Werte der Assemblyattribute überprüfen

<Assembly: AssemblyTitle("oob-downloader")> 
<Assembly: AssemblyDescription("A small program that lets you download files from a webserver")> 
<Assembly: AssemblyCompany("OrangeOnBlack")> 
<Assembly: AssemblyProduct("oob-downloader")> 
<Assembly: AssemblyCopyright("Copyright © OrangeOnBlack 2010")> 
<Assembly: AssemblyTrademark("OrangeOnBlack")> 

<Assembly: ComVisible(False)>

'Die folgende GUID bestimmt die ID der Typbibliothek, wenn dieses Projekt für COM verfügbar gemacht wird
<Assembly: Guid("f8b7d1e4-5a40-4726-a68e-7c2dbe946a62")> 

' Versionsinformationen für eine Assembly bestehen aus den folgenden vier Werten:
'
'      Hauptversion
'      Nebenversion 
'      Buildnummer
'      Revision
'
' Sie können alle Werte angeben oder die standardmäßigen Build- und Revisionsnummern 
' übernehmen, indem Sie "*" eingeben:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("0.0.0.1")> 
<Assembly: AssemblyFileVersion("0.0.0.1")> 
