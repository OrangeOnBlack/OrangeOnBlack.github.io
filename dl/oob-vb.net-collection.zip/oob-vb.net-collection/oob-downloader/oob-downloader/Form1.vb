﻿Public Class Form1
    Dim timetoken As Long = DateDiff("d", Now.Date, "27.02.2011")
    Dim filename As String

    'Server/Login Daten
    Dim server As String = "SERVER_ADRESSE_HIER_EINTRAGEN"
    Dim username As String = "SERVER_USER_HIER_EINTRAGEN"
    Dim password As String = "USER_PASSWORT_HIER_EINTRAGEN"


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        'Speicherort auswaehlen.
        SaveFileDialog1.ShowDialog()
        TextBox5.Text = SaveFileDialog1.FileName

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox5.Focus()
        'Ueberpruefung ob das Programm bereits abgelaufen ist.
        If timetoken < 0 Then
            Me.Text += " [expired!]"
        Else
            Me.Text += " [" & timetoken & " days remain]"
        End If


        'Dateien auf dem Server abfragen/auflisten.
        Try
            Dim request As Net.FtpWebRequest = Net.FtpWebRequest.Create("ftp://" & server)
            request.Method = Net.WebRequestMethods.Ftp.ListDirectory
            request.Credentials = New Net.NetworkCredential(username, password)
            Dim response As Net.FtpWebResponse = request.GetResponse()
            ListBox1.Items.Clear()
            Using myReader As New IO.StreamReader(response.GetResponseStream())
                Do While myReader.EndOfStream = False
                    ListBox1.Items.Add(myReader.ReadLine())
                Loop
            End Using
        Catch
        End Try

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Download der gewaehlten Datei
        Try
            If timetoken >= 0 Then
                My.Computer.Network.DownloadFile("http://" & server & "/" & filename, SaveFileDialog1.FileName, username, password, True, 10, True, FileIO.UICancelOption.DoNothing)
            Else : MsgBox("Download failed!" & vbNewLine & "The time token ran out of time. No, chance. Sorry ...", MsgBoxStyle.Critical, "hmm, something went wrong ...")
            End If
        Catch
            MsgBox("Download failed!" & vbNewLine & "Please check username, password & server address ...", MsgBoxStyle.Critical, "hmm, something went wrong ...")
        End Try

    End Sub

    Private Sub ListBox1_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedValueChanged
        'Auswahl der herunterzuladenden Datei, wenn ein anderer Eintrag selektiert wird.
        filename = ListBox1.SelectedItem
        SaveFileDialog1.FileName = filename
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        'Dateien auf dem Server abfragen/auflisten.
        Try
            Dim request As Net.FtpWebRequest = Net.FtpWebRequest.Create("ftp://" & server)
            request.Method = Net.WebRequestMethods.Ftp.ListDirectory
            request.Credentials = New Net.NetworkCredential(username, password)
            Dim response As Net.FtpWebResponse = request.GetResponse()
            ListBox1.Items.Clear()
            Using myReader As New IO.StreamReader(response.GetResponseStream())
                Do While myReader.EndOfStream = False
                    ListBox1.Items.Add(myReader.ReadLine())
                Loop
            End Using
        Catch
            MsgBox("Download failed!" & vbNewLine & "Please check username, password & server address ...", MsgBoxStyle.Critical, "hmm, something went wrong ...")
        End Try


    End Sub
End Class