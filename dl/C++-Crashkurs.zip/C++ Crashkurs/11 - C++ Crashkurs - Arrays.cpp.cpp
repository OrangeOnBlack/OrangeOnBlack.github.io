#include <iostream>

using namespace std;

int main(void) {
    
    /* Array deklarieren */
    /* 5 Speicherpl�tze: [0], [1], [2], [3], [4] */
    int meinArray[5];
    /* ACHTUING: meinArray[5] kann man jedoch nicht belegen! */
    
    /* Array mit Werten f�llen (nur Beispiele) */
                              //  ___Tabelle____
    meinArray[0] = 10;        // |  [0]  |  10  |
    meinArray[1] = 11;        // |  [1]  |  11  |
    meinArray[2] = 12;        // |  [2]  |  12  |        
    meinArray[3] = 13;        // |  [3]  |  13  |
    meinArray[4] = 14;        // |  [4]  |  14  |
                              // |_______|______|
    
    /* Einzelnes Datenelement ausgeben */
    /* Folgendes gibt "10" aus */
    cout << meinArray[0] << endl;
    
    /* Gesamtes Array ausgeben */
    for(int i = 0; i < 5; i++) {
        cout << "Element " << i  << "\t" << meinArray[i] << endl;
    }
    
    cin.sync();
    cin.get();
}
