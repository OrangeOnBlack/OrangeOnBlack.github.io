#include <iostream>
#include <strings.h>

using namespace std;

int main(void)
{
    //W�rter oder S�tze speichern
    
    //char Array (viele chars mit jeweils 1 Buchstaben)
    char charSatz[] = {"OrangeOnBlack C++ Crashkurs\n"};
    cout << charSatz;
    
    //Datentyp speziell f�r Zeichenketten: String
    //Vorteil: Keine umst�ndlichen char Arrays
    string stringSatz = "OrangeOnBlack C++ Crashkurs\n";
    cout << stringSatz;
    
    cin.sync();
    cin.get();
    return 0;
}
