#include <iostream>

using namespace std;

int main(void)
{
    //Addition
    int ergebnisAdd;
    ergebnisAdd = 27 + 3;
    
    //Subtraktion
    int ergebnisSub;
    ergebnisSub = 103 - 3;
    
    //Multiplikation
    int ergebnisMul;
    ergebnisMul = 7 * 7;
    
    //Division
    int ergebnisDiv;
    ergebnisDiv = 20 / 2;
    
    //Modulo (liefert Rest einer Division)
    int ergebnisMod;
    ergebnisMod = 10 % 3;
    
    cout << ergebnisAdd << endl
         << ergebnisSub << endl
         << ergebnisMul << endl
         << ergebnisDiv << endl
         << ergebnisMod << endl;
         
    cin.get();
    return 0;
}
