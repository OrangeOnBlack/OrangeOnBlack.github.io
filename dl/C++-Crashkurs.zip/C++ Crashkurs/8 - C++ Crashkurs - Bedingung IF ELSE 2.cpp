#include <iostream>

using namespace std;

int main(void)
{
    int alter;
    cout << "Du musst ueber 18 Jahre alt sein!" << endl
         << "Bitte gib dein Alter an: ";
    cin >> alter;
    
    if( alter >= 18 ) {//Bedingung
        cout << "Du bist " << alter << " Jahre alt." << endl//wenn erf�llt,
             << "Programm wird geladen...";//dann wird dieser Code ausgef�hrt
    } else {//ansonsten wird folgender Code ausgef�hrt
        cout << "Du bist leider zu jung. Nur noch: " << 18 - alter << " Jahre";
    }
    
    cin.sync();
    cin.get();
    return 0;
}
