#include <iostream>
#include <conio.h>

using namespace std;

int main(void)
{
    int a;
    
    /*
     _Speicherzellen_______________ _____________
     |  [1]  |  [2] |  [3] |  [4] |  [5]  |  [6] |
     |  127  |  42  |   7  | 1024 | 31415 | 1337 |
     |_______|______|______|______|_______|______|
    */
    
    //Adresse ausgeben
    cout << "Adresse von a: " << &a << endl;
    
    //Datentyp, der Adressen speichert: Zeiger (Pointer)
    int *zeigerAufA = &a;
    
    cout << "Fuer die erste Methode 1 eingeben\n"
         << "Fuer die zweite Methode 2 eingeben\n";
         
    char eingabe;
    do {
        eingabe = getch();//Buchstabe von Tastatur abfangen (ohne ENTER)
        
        if(eingabe == '1') {
            a = 7;
            cout << "a = " << a << endl;
        } else if (eingabe == '2') {
            *zeigerAufA = 42;
            cout << "a = " << a << endl << endl;
            cout << "zeigerAufA = " << zeigerAufA << endl;//zeigerAufA (ADRESSE)
            cout << "*zeigerAufA = " << *zeigerAufA << endl;//*zeigerAufA (WERT)
        } else {
            return 0;
        }
        
    } while((eingabe == '1') || (eingabe == '2'));
    
    return 0;

}
