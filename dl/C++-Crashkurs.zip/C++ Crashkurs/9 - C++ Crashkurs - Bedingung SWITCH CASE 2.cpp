#include <iostream>

using namespace std;

int main(void)
{
    cout << "Waehle einen Modus:\n"
         << "\t1. Singleplayer\n"
         << "\t2. Multiplayer\n"
         << "\t3. Optionen\n"
         << "\t4. Beenden\n"
         << "Auswahl: ";
    
    char auswahl;
    cin >> auswahl;
    
    switch( auswahl ) {
            case '1':
                 cout << "Singleplayer wird geladen ...";
                 break;
            case '2':
                 cout << "Multiplayer wird geladen ...";
                 break;
            case '3':
                 cout << "Optionen werden geladen ...";
                 break;
            case '4':
                 return 0;
    }
         
         cin.sync();
         cin.get();
         return 0;
}
