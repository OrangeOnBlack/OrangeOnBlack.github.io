#include <iostream>

int main(void)
{
    std::cout << "Erste Zeile."; //kein Zeilenumbruch am Ende
    std::cout << "Immer noch erste Zeile.";
    std::cout << std::endl; //einzelner Zeilenumbruch
    std::cout << "Zweite Zeile.\n"; //2. Zeile.
    /* \n innerhalb von Anf�hungszeichen ist
    das Gleiche wie std::endl*/

    
    std::cin.get(); //H�lt die Konsole offen; wartet auf ENTER
    return 0;
}
