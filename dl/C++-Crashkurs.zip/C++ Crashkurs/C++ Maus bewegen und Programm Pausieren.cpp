#include <windows.h> //Windows-Funktionen verwenden

using namespace std;

int main(void)
{
    int x, y;
    x = 100;
    y = 100;
    for(int i=0; i<10; i++)
    {
        SetCursorPos(x,y); //Mauszeiger bewegen
        x = x + 25;
        y = y + 25;
        Sleep(1000); //1 Sekunde Programm pausieren
    }
    return 0; //Programm ordentlich beenden
}
