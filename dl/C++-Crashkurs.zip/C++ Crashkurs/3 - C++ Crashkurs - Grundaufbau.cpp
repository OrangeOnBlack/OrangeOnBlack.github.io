#include <iostream>

int main(void)
{
    int temp;
    char temp2;
    
    temp = 42;
    temp2 = 'Y';
    
    std::cin.get();
    return 0;
}
