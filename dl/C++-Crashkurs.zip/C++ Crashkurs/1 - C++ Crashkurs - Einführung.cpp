#include <iostream>
#include <String.h>

using namespace std;

int main(void){
    string name = "OrangeOnBlack";
    string registriertSeit = "27.01.2010";
    int kanalaufrufe = 18623;
    int abonnenten = 909;
    int videoaufrufe = 275553;
    
    cout << "Name: " << name << "\n"
         << "registriert seit: " << registriertSeit << "\n"
         << endl
         << "Vielen Dank allen Viewern & Abonnenten fuer: \n"
         << "\t" << kanalaufrufe << "\t" << "Kanalaufrufe" << "\n"
         << "\t" << abonnenten << "\t" << "Abonnenten" << "\n"
         << "\t" << videoaufrufe << "\t" << "Videoaufrufe" << "\n";
         
    cin.get();
}
