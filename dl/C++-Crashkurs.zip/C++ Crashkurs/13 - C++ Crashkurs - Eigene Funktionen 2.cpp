#include <iostream>

using namespace std;

//Prototypen von allen Funtkionen im Programm
float subtraktion();//mit R�ckgabewert, ohne �bergabeparameter


int main(void)
{
    
    cout << subtraktion();
    
    cin.sync();
    cin.get();
    return 0;
}

float subtraktion()
{
     float zahl_1, zahl_2;
     cout << "Zahl 1 eingeben: ";
     cin >> zahl_1;
     cout << "Zahl 2 eingeben: ";
     cin >> zahl_2;
     return zahl_1 - zahl_2;
}
