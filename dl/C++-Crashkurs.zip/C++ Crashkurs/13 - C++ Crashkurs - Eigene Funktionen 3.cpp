#include <iostream>

using namespace std;

//Prototypen von allen Funtkionen im Programm
void multiplikation(float zahl_1, float zahl_2);/*ohne R�ckgabewert,
                                                mit �bergabeparameter*/


int main(void)
{
       
    float zahl_1, zahl_2;
    
    cout << "Zahl 1 eingeben: ";
    cin >> zahl_1;
    cout << "Zahl 2 eingeben: ";
    cin >> zahl_2;
    multiplikation(zahl_1, zahl_2);//ohne R�ckgabewert, mit �bergabeparameter
    
    cin.sync();
    cin.get();
    return 0;
}

void multiplikation(float a, float b)
{
     cout << a * b;
}

