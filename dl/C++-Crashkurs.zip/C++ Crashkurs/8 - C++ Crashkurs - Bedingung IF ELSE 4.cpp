Zusammenfassung:
    Vergleiche
        Operator    Erkl�rung
        ==          Pr�fung auf Gleichheit
        !=          Pr�fung auf Ungleichheit
        <=          Pr�fung auf kleiner oder gleich
        >=          Pr�fung auf gr��er oder gleich
        <           Pr�fung auf kleiner als
        >           Pr�fung auf gr��er als

    Logische Operatoren
        Operator    Erkl�rung
        &&          Beide Bedingungen m�ssen wahr sein
        ||          Mindestens eine Bedingung muss wahr sein
