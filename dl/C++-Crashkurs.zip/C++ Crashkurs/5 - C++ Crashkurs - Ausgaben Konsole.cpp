#include <iostream>

using namespace std; //erspart std:: vor cout und weiteren Befehlen

int main(void)
{
    cout << "Erste Zeile." //kein ; Befehl geht also weiter
         << "Immer noch erste Zeile."
         << endl
         << "Zweite Zeile.\n";

    
    cin.get();
    return 0;
}
