#include <iostream>

using namespace std;

//Prototypen von allen Funtkionen im Programm
void addition();//ohne R�ckgabewert, ohne �bergabeparameter


int main(void)
{
    
    addition();
    
    cin.sync();
    cin.get();
    return 0;
}

void addition()
{
     float zahl_1, zahl_2;
     cout << "Zahl 1 eingeben: ";
     cin >> zahl_1;
     cout << "Zahl 2 eingeben: ";
     cin >> zahl_2;
     cout << zahl_1 + zahl_2;
}
