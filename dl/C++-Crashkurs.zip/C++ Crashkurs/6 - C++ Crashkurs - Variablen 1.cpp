#include <iostream>

using namespace std;

int main(void)
{
    /* Variablennamen: Buchstaben, Ziffern & Unterstriche */
    int meineZahl; //eine Ganzzahl (Bsp.: 42)
    float meineKommazahl; //eine Kommazahl (Bsp.: 3.14159)
    double meineLangeKommaZahl;
    char meinZeichen; /*Zahl -128 bis 127
                     oder ein Buchstabe*/
    unsigned char meinZeichen2; /*gleiche Gr��e f�r die Variable
                              m�glich, aber nun vorzeichenlos
                              (ohne negative Zahlen)*/
                     
    bool meinJaNein; //wahr(true) od. falsch(false)
    
    /* Variablen haben immer eine festgelegte Gr��e,
    deshalb k�nnen auch nur Zahlen bis zu einer
    bestimmten Gr��e in ihnen gespeichert werden. */
    cout << "kleinstmoegliche Integerzahl: " << INT_MIN << endl
         << "groesstmoegliche Integerzahl: " << INT_MAX << endl;
         
    /* WICHTIG: Es wird zwischen Gro�-/Kleinschreibung unterschieden!*/
    int VAR1; //ist eine andere Variable als:
    int var1;
    
    cin.get();
    return 0;
}
