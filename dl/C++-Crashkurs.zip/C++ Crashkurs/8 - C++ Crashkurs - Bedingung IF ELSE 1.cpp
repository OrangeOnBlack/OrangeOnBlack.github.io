#include <iostream>

using namespace std;

int main(void)
{
    int alter;
    cout << "Du musst ueber 18 Jahre alt sein!" << endl
         << "Bitte gib dein Alter an: ";
    cin >> alter;
    
    if( alter >= 18 ) { //Bedingung
        cout << "Du bist " << alter << " Jahre alt." << endl //wenn erf�llt,
             << "Programm wird geladen..."; //dann wird dieser Code ausgef�hrt
    }
    
    cin.sync();
    cin.get();
    return 0;
}
