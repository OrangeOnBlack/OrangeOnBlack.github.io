#include <iostream>

using namespace std;

int main(void)
{
    int alter;
    cout << "Du musst ueber 18 Jahre alt sein!" << endl
         << "Bitte gib dein Alter an: ";
    cin >> alter;
    
    if( alter >= 18 ) {//Bedingung
        cout << "Du bist " << alter << " Jahre alt." << endl
             << "Programm wird geladen...";
    } else if( (alter > 12) && (alter < 18) ) {//ansonsten wird diese Bedingung gepr�ft                                      //beide Bedingungen m�ssen wahr sein
        cout << "OK, Du bist " << alter << " Jahre alt." << endl
             << "Eingeschraenkte Inhalte werden geladen.";
    } else {//falls beide Bedingungen falsch, dann passiert Folgendes:
        cout << "Du bist leider zu jung. Nur noch: " << 18 - alter << " Jahre";
    }
    
    cin.sync();
    cin.get();
    return 0;
}
