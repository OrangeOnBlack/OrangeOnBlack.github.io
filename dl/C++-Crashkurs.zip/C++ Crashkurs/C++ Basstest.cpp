#include <windows.h> //Windows-Funktionen verwenden
#include <iostream> //Text Aus-/Eingaben erm�glichen

using namespace std;

int main(void)
{
    cout << "LOADING BASS TEST . . ." << endl;
    
    for(int i = 5; i >= 1; i--) //Countdown 5, 4, ... 1
    {
        cout << i << endl;
        Sleep(1000);
    }
    
    system("cls"); //Konsole leeren
    
    for(int i = 150; i >= 10; i = i - 10) //Sound erzeugen
    {
        cout << "BASS TEST PROGRESS: " << i << "Hz" << endl;
        Beep(i,5000); //(Frequenz in Hz, Dauer in Millisekunden)
        system("cls"); //Konsole leeren
    }
    
    cout << "BASS TEST FINISHED!";
    cin.get(); // Fenster offen halten
    return 0; //Programm ordentlich beenden
}
