#include <iostream>

using namespace std;

int main(void)
{                   //0     1      2      3
    enum augenfarbe {blau, grau, braun, gruen};//enum: Datentyp f�r Aufz�hlungen
    
    augenfarbe bspAugenfarbe;/*Variable vom Typ augenfarbe anlegen.
                              augenfarbe ist nun Datentyp (wie int, char ...)*/
                              
    bspAugenfarbe = gruen;//"Schalter umlegen"
    cout << bspAugenfarbe;//Ausgabe zeigt 3 an (weil gr�n = 3, s.o.)
    
    cin.sync();
    cin.get();
    return 0;
}
