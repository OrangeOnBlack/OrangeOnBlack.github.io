#include <iostream>
#include <strings.h>

using namespace std;

int main(void)
{
    
    enum augenfarbe {blau, grau, braun, gruen};
    
    struct Person { //struct: Datenspeicher in selbstgew�hlter Form
        string name;
        int alter;
        augenfarbe bspAugenfarbe;
    };
    
    Person peter;
    peter.name = "peter";
    peter.alter = 32;
    peter.bspAugenfarbe = gruen;
    
    cout << peter.name << endl
         << peter.alter << endl
         << peter.bspAugenfarbe;
    
    cin.sync();
    cin.get();
    return 0;
}
