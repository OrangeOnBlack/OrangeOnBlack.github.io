#include <iostream>

using namespace std;

//Prototypen von allen Funtkionen im Programm
float division(float zahl_1, float zahl_2);/*mit R�ckgabewert
                                           mit �bergabeparameter*/

int main(void)
{
    
    float zahl_1, zahl_2;

    cout << "Zahl 1 eingeben: ";
    cin >> zahl_1;
    cout << "Zahl 2 eingeben: ";
    cin >> zahl_2;
    cout << division(zahl_1, zahl_2);//mit R�ckgabewert, mit �bergabeparameter
    
    cin.sync();
    cin.get();
    return 0;
}

float division(float a, float b)
{
     return a / b;
}
