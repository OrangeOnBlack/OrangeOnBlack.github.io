package katzen;

public class Tiger extends Raubkatze {
	Tiger(int gewicht) {
		super("Tiger", gewicht, "Alles und jeder");
	}
	
}