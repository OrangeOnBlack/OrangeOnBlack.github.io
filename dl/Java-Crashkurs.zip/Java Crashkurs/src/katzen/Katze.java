package katzen;

public class Katze {
	String rasse; 	// Rasse der Katze
	int gewicht;	// Gewicht der Katze
	
	// Kostruktor
	Katze(String dieRasse, int dasGewicht) {
		rasse = dieRasse;
		gewicht = dasGewicht;
	}
	
}
