# Importieren der Funktion 'randint' mit dem Alias 'rint' des Moduls 'random'
from random import randint as rint

# Zugreifen auf die Funktion 'randint' mit dem Alias 'rint' des Moduls 'random'
print(rint(7 ,42))