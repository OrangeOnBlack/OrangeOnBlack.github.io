def schlaue_funktion():
	print("Hier arbeitet die Funktion des Moduls ohne main")

# Der Hauptteil des Programms
print("Hier arbeitet der Hauptteil des Moduls ohne main")