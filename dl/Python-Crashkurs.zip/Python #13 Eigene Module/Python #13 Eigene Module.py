# Importiert beide Module (im selben Ordner)
import eigenes_modul_ohne_main
import eigenes_modul_mit_main


print("Hier arbeitet das Programm")
eigenes_modul_ohne_main.schlaue_funktion()
eigenes_modul_mit_main.schlaue_funktion()