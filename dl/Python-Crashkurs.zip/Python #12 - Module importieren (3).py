# Importieren des Moduls 'random' mit dem Alias 'r'
import random as r

items = ["Schwert", "Gold", "Baumstamm", "Käse"]
# Zugreifen auf die Funktion 'choice' des importierten Moduls 'random' als 'r' 
print(r.choice(items))