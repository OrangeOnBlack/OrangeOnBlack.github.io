# Importieren des Moduls 'random'
import random

# Zugreifen auf eine Funktion des Moduls 'random'
print(random.randint(7 ,42))