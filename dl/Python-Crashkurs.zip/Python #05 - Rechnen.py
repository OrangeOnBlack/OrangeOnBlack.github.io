# Rechnen

# Grundrechenarten + - * /
print(4 + 3)
print(25 - 4)
print(84 * 2)
print(7 / 7)

# Potenz **
print(2 ** 10)

# Rechnen mit Variablen
zahl1 = 6
zahl2 = 7
zahl3 = zahl1 * zahl2
print(zahl3)
print(zahl1 * 5)

print((zahl2 + 3) * 10)

# Modulo % (Rest der Division)
print(10 % 2)
print(11 % 2)