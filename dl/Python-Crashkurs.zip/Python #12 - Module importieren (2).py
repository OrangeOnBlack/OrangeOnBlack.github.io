# Importieren der Funktion 'randint' des Moduls 'random'
from random import randint

# Zugreifen auf die importierte Funktion 'randint'
print(randint(7 ,42))